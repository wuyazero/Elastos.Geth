"use strict";

module.exports = {
  kstore: {"address":"d9758863f280c25b0d1f2f81705e3725ccd5ac49","crypto":{"cipher":"aes-128-ctr","ciphertext":"a556b482ab892f633c860cc93907e0672541a74e2ee4afbb60fdb6cda310b100","cipherparams":{"iv":"f2cef362abb7f9303e72c7a62e90b9d7"},"kdf":"scrypt","kdfparams":{"dklen":32,"n":262144,"p":1,"r":8,"salt":"2422d56e010451134893f841d7b7836af155c195753429255441c8c34dff1170"},"mac":"7243b9238cd6857841327db76c1ce6d2cea8b501a43b3a99fe54c1255408e686"},"id":"5f14e73b-f0e3-40cd-a0c6-4ef9e6842acd","version":3},
  kpass: "12345678"
}
