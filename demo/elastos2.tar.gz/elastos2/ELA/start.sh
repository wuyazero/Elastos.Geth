#! /bin/bash
nohup ./ela > ./Logs/ela.log 2>&1 &
