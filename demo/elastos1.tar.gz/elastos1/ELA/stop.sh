#! /bin/bash
pkill -INT ela
pkill -TERM ela
