#! /bin/bash
pkill -INT bootnode
