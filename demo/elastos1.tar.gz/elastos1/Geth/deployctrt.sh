#! /bin/bash
node ./deployctrt.js
