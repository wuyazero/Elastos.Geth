#! /bin/bash
nohup ./geth --datadir "./data" --bootnodes "enode://0e96be781e9e2bc7a960e60bf597847f6aec476c2dcf4b14d7cc5f1722c5e70184b71c955c2fb4b263f3c02b7ebb1395346b828e3c0a25fcafc18e47a505f033@127.0.0.1:30301" --port 6066 --rpc --rpcaddr "127.0.0.1" --rpcport 6666 --rpcapi "personal,db,eth,net,web3,txpool,miner" --networkid 666 --spvmoniaddr "XKUh4GLhFJiqAMTF6HyWQrV9pK9HcGUdfJ" --unlock "0x840534b46b3b3bf8c1c3e4c7d34bc86933de7814" --password "./pass.txt" --mine > ./Logs/geth.log 2>&1 &
pm2 start crosschain_oracle.js -i 1 -e ./Logs/oracle_err.log -o ./Logs/oracle_out.log
