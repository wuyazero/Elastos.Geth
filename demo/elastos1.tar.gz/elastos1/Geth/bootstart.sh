#! /bin/bash
nohup ./bootnode -nodekey boot.key > ./Logs/boot.log 2>&1 &
