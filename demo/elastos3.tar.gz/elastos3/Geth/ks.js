"use strict";

module.exports = {
  kstore: {"address":"8bf2e42de44c50e2966a98ddc0e2a79ce0e949f5","crypto":{"cipher":"aes-128-ctr","ciphertext":"6ebf9be2a7359c5eb9128534bd7e2da847d77d838c105993801fa68737393354","cipherparams":{"iv":"fec0c81115e14129151d5b8fc11be217"},"kdf":"scrypt","kdfparams":{"dklen":32,"n":262144,"p":1,"r":8,"salt":"68826eeb2101c25ef55a5cb1caa42c51d8e835b722a8dc5fc324840218f30780"},"mac":"c5832d77c0b353833f1f8d9e1e56de365cd7e9667609ad5f98f5578ba148f91c"},"id":"085aa3f7-0ee0-408d-876c-bda8409acd16","version":3},
  kpass: "12345678"
}
