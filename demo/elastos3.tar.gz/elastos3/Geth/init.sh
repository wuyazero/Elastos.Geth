#! /bin/bash
./geth init Elastos.Geth.json --datadir="./data"
