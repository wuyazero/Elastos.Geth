#! /bin/bash
pm2 kill
pkill -INT geth
